# Cheese Fantasy Draft Review 2025/26

A shareable Streamlit dashboard for reviewing the league's fantasy-football draft.

The app reads its data directly from the GitHub repository. League members do **not** need to upload a file when they open it.

## Included views

- League overview and draft-score table
- Ten best later-round selections and ten worst early selections
- Team report cards with a transparent score out of ten
- Team-by-team breakdowns
- Searchable player explorer
- CSV downloads for league chat and follow-up analysis

## Repository structure

Keep these files and folders together:

```text
fantasy_draft_app/
├── streamlit_app.py
├── requirements.txt
├── README.md
├── .streamlit/
│   └── config.toml
└── data/
    └── draft_data.csv
```

The live app always loads:

```text
data/draft_data.csv
```

## Put the data into GitHub

1. Create a GitHub repository.
2. Unzip this project and upload all its contents to the repository.
3. Make sure `data/draft_data.csv` is committed alongside the app code.
4. Deploy `streamlit_app.py` through Streamlit Community Cloud.

Nobody visiting the deployed app will be asked to upload data.

## Updating the data later

Replace `data/draft_data.csv` in GitHub with the updated CSV, keeping the same filename and column headings. Commit the change to the branch used by Streamlit.

Streamlit Community Cloud normally detects the new commit and refreshes the app. If necessary, use **Reboot app** from the Streamlit app-management page.

## Expected columns

The repository CSV must contain these key columns:

- Fantasy Team
- Round
- Ov Pick
- Pos
- Player
- DraftGP
- DraftPts
- DraftRank
- DrafRankDelta
- SeasonPts
- SeasonRank
- SeasonDelta
- Utilisation

Additional columns such as `Team`, `Pick`, `DraftPPG`, `SeasonGP` and `SeasonPPG` may also be included.

## Run locally

```bash
python -m venv .venv
# Windows
.venv\Scripts\activate
# macOS / Linux
source .venv/bin/activate

pip install -r requirements.txt
streamlit run streamlit_app.py
```

## Deploy on Streamlit Community Cloud

1. Sign in to Streamlit Community Cloud with GitHub.
2. Choose **Create app**.
3. Select the repository and branch.
4. Set the entrypoint to `streamlit_app.py`.
5. Deploy and share the resulting `streamlit.app` address with the league.

No secrets, external database or user-upload process are required.

## Scoring

The team score is comparative within the repository dataset:

- 40% total DraftPts
- 25% cumulative DrafRankDelta
- 15% total SeasonPts
- 10% weighted utilisation
- 10% number of positive-value selections

Metrics are min-max normalised, combined, and placed on a report-card scale.
